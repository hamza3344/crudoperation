﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace crudcsv
{
    public partial class Form1 : Form
    {
        string path = "file.csv";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if(!File.Exists(path))
            {
                File.Create(path).Dispose();
                using(TextWriter tw=new StreamWriter(path))
                {
                    tw.WriteLine("id,name,location");
                }
            }
            gridview();
        }

        private void add_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (File.Exists(path))
            {
                try
                {
                    count = Convert.ToInt32(File.ReadAllLines(path).Last().Split(',')[0]);
                    count = count + 1;
                }
                catch(Exception e1)
                {
                    count = 1;
                }
                File.AppendAllLines(path, new[] { count.ToString() + "," + txtname.Text + "," + txtlocation.Text });
            }
            gridview();
        }
        public void gridview()
        {
            dataGridView1.DataSource = null;
            DataTable dt = new DataTable();
            dt.Columns.Add("ID");
            dt.Columns.Add("Name");
            dt.Columns.Add("Location");
            string[] lines = File.ReadAllLines(path);
            lines = lines.Skip(1).ToArray();
            foreach(string line in lines)
            {
                DataRow row = dt.NewRow();
                string[] values = line.Split(',');
                int i = 0;
                foreach(string value in values)
                {
                    row[i] = value;
                    i = i + 1;
                }
                dt.Rows.Add(row);
            }
            
            dataGridView1.DataSource = dt;









        }

        private void update_Click(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(path);
            int j = 0;
            foreach(string line in lines)
            {
                if(line.Split(',')[0]==lblid.Text)
                {
                    break;
                }
                else
                {
                    j = j + 1;
                }
            }
            lines[j] = lines[j].Split(',')[0] + "," + txtname.Text + "," + txtlocation.Text;
            File.WriteAllLines(path, lines);
            gridview();























        }

        private void delete_Click(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(path);
            int j = 0;
            foreach(string line in lines)
            {
                if(line.Split(',')[0]==lblid.Text)
                {
                    break;
                }
                else
                {
                    j = j + 1;
                }
            }
            string[] newlines = lines.Where(g => !g.Equals(lines[j])).ToArray();
            File.WriteAllLines(path, newlines);
            gridview();



















        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if(e.RowIndex>=0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                lblid.Text = row.Cells[0].Value.ToString();
            }
        }
    }
}
